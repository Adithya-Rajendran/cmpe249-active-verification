"""Score anonymous archived queries with the official prompt, crops and first-token readout."""
import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

import torch
import transformers
from transformers import AutoModelForImageTextToText, AutoProcessor


def save(path, data):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, allow_nan=False) + "\n")
    temp.replace(path)


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def place_items(scene, anchors, directory):
    import build_crops
    directory.mkdir(exist_ok=True)
    output = []
    if set(anchors) != {r["id"] for r in scene}:
        raise ValueError("Anchor inventory differs from the blinded items")
    for row in scene:
        uid = row["id"]
        frame, box, visible = anchors[uid]
        if frame is None or visible < build_crops.PI3_MIN or box[2] <= box[0] or box[3] <= box[1]:
            continue
        if frame != 1:
            raise ValueError("A two-image query has only one revisit")
        files = [directory / (uid + suffix) for suffix in ("-object.jpg", "-place.jpg")]
        build_crops.crop(row["images"][0], row["query"]["bbox_2d"], files[0])
        build_crops.crop(row["images"][1], box, files[1])
        output.append(dict(id=uid, task="crop", images=list(map(str, files)), q=build_crops.Q))
    return output


def answer_probs(batch, model, proc, groups):
    from still_common import content, encode, images
    texts = [proc.apply_chat_template([{"role": "user", "content": content(row)}],
                                      tokenize=False, add_generation_prompt=True,
                                      enable_thinking=False) for row in batch]
    pictures = [picture for row in batch for picture in images(row)]
    enc = encode(proc, texts, pictures, "V", padding=True).to("cuda")
    with torch.inference_mode():
        logits = model(**enc, logits_to_keep=1).logits[:, -1].float()
        vocab = logits.softmax(-1)
        by_word = torch.stack([vocab[:, indices].sum(-1) for indices in groups], dim=-1)
        norm = by_word.sum(-1, keepdim=True)
        if not torch.isfinite(norm).all() or (norm <= 0).any():
            raise ValueError("Invalid answer-token mass")
        return (by_word / norm).cpu(), norm.flatten().tolist()


def score(rows, mode, split, root, model, proc, groups, binding):
    output = root / f"probabilities-{split}-{mode}.json"
    batch_record = root / f"batch-{mode}.json"
    if split == "dev" and not batch_record.exists():
        trial = rows[:4]
        batched, _ = answer_probs(trial, model, proc, groups)
        singles = torch.cat([answer_probs([r], model, proc, groups)[0] for r in trial])
        delta = (batched - singles).abs().max().item()
        save(batch_record, dict(batch_size=4 if delta <= 0.02 else 1, max_probability_difference=delta,
                                check_ids=[r["id"] for r in trial]))
    bs = json.loads(batch_record.read_text())["batch_size"]
    binding = dict(binding, batch=bs, mode=mode, split=split, count=len(rows))
    if output.exists():
        existing = json.loads(output.read_text())
        if existing["binding"] != binding:
            raise ValueError("Cannot resume with a different scoring configuration")
        result = existing["rows"]
    else:
        result = {}
    pending = [r for r in rows if r["id"] not in result]
    start = time.monotonic()
    for i in range(0, len(pending), bs):
        batch = pending[i:i + bs]
        probs, mass = answer_probs(batch, model, proc, groups)
        for r, p, m in zip(batch, probs.tolist(), mass):
            if not math.isclose(sum(p), 1.0, abs_tol=1e-5):
                raise ValueError("Unnormalized probabilities")
            result[r["id"]] = dict(p=p, answer_token_mass=m)
        if i % 32 == 0 or i + bs >= len(pending):
            save(output, dict(binding=binding, rows=result))
            print(f"{split} {mode} {len(result)}/{len(rows)} cases, {time.monotonic()-start:.1f}s", flush=True)
    if set(result) != {r["id"] for r in rows}:
        raise ValueError("Incomplete score table")


def main(root, split):
    root = root.resolve()
    if split == "main" and not (root / "thresholds.json").is_file():
        raise ValueError("Development thresholds must be fixed before main inference")
    settings = json.loads((root / "settings.json").read_text())
    src = root / "upstream"
    sys.path.insert(0, str(src / "scripts"))
    model_dir = Path((root / "STILL-Qwen3.5-9B.location").read_text().strip())
    if model_dir.name != settings["model_revision"]:
        raise ValueError("Unexpected verifier revision")
    weights = file_hash(model_dir / "model.safetensors")
    if weights != settings["model_weights_sha256"]:
        raise ValueError("Unexpected verifier weights")
    items_path = src / "data/p2" / f"items_cmpe_{split}.jsonl"
    anchor_path = src / "data/p2" / f"pi3_anchor_cmpe_{split}.json"
    scene = [json.loads(line) for line in items_path.read_text().splitlines()]
    place = place_items(scene, json.loads(anchor_path.read_text()), root / f"crops-{split}")
    proc = AutoProcessor.from_pretrained(model_dir, local_files_only=True)
    proc.tokenizer.padding_side = "left"
    words = ("same", "changed", "unseen")
    groups = [sorted({proc.tokenizer(w, add_special_tokens=False).input_ids[0]
                      for w in (word, word.capitalize())}) for word in words]
    model = AutoModelForImageTextToText.from_pretrained(model_dir, local_files_only=True,
                                                        dtype=torch.bfloat16, attn_implementation="sdpa")
    model = model.to("cuda").eval()
    binding = dict(weights_sha256=weights, settings_sha256=file_hash(root / "settings.json"),
                   code_sha256=file_hash(Path(__file__)), items_sha256=file_hash(items_path),
                   anchor_sha256=file_hash(anchor_path), words=words, token_ids=groups,
                   torch=str(torch.__version__), transformers=transformers.__version__,
                   gpu=torch.cuda.get_device_name(), thresholds_sha256=file_hash(root / "thresholds.json")
                   if split == "main" else None)
    # JSON round-trip converts the word tuple into its stored list form on resume.
    binding = json.loads(json.dumps(binding))
    print(f"{split}: {len(scene)} unique scene queries, {len(place)} valid places", flush=True)
    for mode, rows in (("place", place), ("scene", scene)):
        score(rows, mode, split, root, model, proc, groups, binding)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("split", choices=["dev", "main"])
    args = parser.parse_args()
    os.environ["HF_HUB_OFFLINE"] = "1"
    main(args.root, args.split)
