# Recount the trained STILL comparison

This package compares removal decisions on the same 1,280 archived queries.
Each simulator contributes 320 removed objects and 320 retained objects.
The project calibrated the thresholds on ten separate development layouts.

## Recount the decisions

1. Download the [project source at the closeout commit](https://github.com/Adithya-Rajendran/cmpe249-active-verification/tree/f1f60cba0a234d7316e98cd60c21cdfafe425cc5).
2. Extract this package into a separate directory.
3. Open a shell in the extracted directory.
4. Set `audit` to the absolute path of the project source.
5. Run these commands with Python 3.11 or later.

```sh
python3 evaluate.py calibrate . "$audit/paper/evidence/exploratory-decisions.csv"
python3 evaluate.py evaluate . "$audit/paper/evidence/queries.csv" "$audit/paper/evidence/pairs.csv"
python3 raw_recount.py . "$audit/paper/evidence"
```

The first command checks the numeric thresholds against the development probabilities.
The second command rebuilds the decision tables and paired intervals.
The third command checks each decision against the original probability files and physical states.
The recount uses the Python standard library.

## Read the evidence

| File | Contents |
| --- | --- |
| `settings.json` | Model revisions, calibration rules and definitions of the primary and secondary comparisons |
| `sources.json` | Authors' model card, registration code, verifier code and file hashes |
| `thresholds.json` | Development counts, chosen thresholds and lock time |
| `probabilities-*.json` | Raw probabilities for same, changed and unseen, with model and input hashes |
| `aliases-*.json` | Query identifiers that share identical images and the same reference box |
| `pi3_anchor_cmpe_*.json` | Registered revisit boxes and visible fractions from Pi3 |
| `main-decisions.csv` | Physical state, scores and decisions for each original query |
| `counts.csv` | Missed removals and false deletions by method, simulator and query subset |
| `exact-pairs.csv` | Deletion decisions on 88 pixel-identical MuJoCo pairs |
| `paired-differences.csv` | Differences in error rates between primary STILL and each comparator, with descriptive layout-bootstrap intervals |
| `raw-recount.json` | Checks of raw scores, model settings, aggregate counts and identical pairs |
| `*-object.jpg` and `*-place.jpg` | Both input crops for the exact tabletop pair that exceeded the conservative threshold |

A missed removal leaves a removed object in memory.
A false deletion erases a retained object.
For STILL, `NO_DELETE` means that the change score fell below the threshold.
For the place-only rule, `UNKNOWN` means that registration supplied no usable crop.
The intervals use 10,000 paired bootstrap draws of whole layouts within each environment.
They treat the development threshold as fixed.

To draw the example with Pillow and Matplotlib, run the following command.

```sh
python3 draw_example.py . "$audit/paper/evidence/pairs.csv" example.png
```

## Inference inputs

The [image release](https://github.com/Adithya-Rajendran/cmpe249-active-verification/releases/tag/scene-memory-audit-v1) contains the development and main archives.
`prepare.py` checks both archives and creates the anonymous model inputs.
The authors' `pi3_anchor.py` projects each reference box into the revisit.
`infer.py` uses the authors' crop and prompt functions and records the answer probabilities.
The main inference requires the development threshold file.

## Repeat model inference with the saved projections

Use a CUDA system for this procedure.
The original run used a GB10, PyTorch 2.12.1+cu130 and Transformers 5.17.0.
The probability files give the exact versions and batch sizes.

1. Set `package` to the directory that contains this extracted package.
2. Set `audit` to the project source directory and `images` to the directory with both image archives.
3. Create an empty directory for the new run.
4. Open a Bash shell in that directory.
5. Prepare the model code and saved registration results.

```sh
cp "$package"/{prepare.py,restore_inputs.py,infer.py,evaluate.py,settings.json,dev-ids.txt,batch-place.json,batch-scene.json} .
git clone https://github.com/Oran9er/STILL.git upstream
git -C upstream checkout --detach ef115fdfbcc69ca53f4874720c9e5eab429ec221
mkdir -p upstream/data/p2
cp "$package"/pi3_anchor_cmpe_{dev,main}.json upstream/data/p2/
python3 - <<'PY'
from pathlib import Path
from huggingface_hub import snapshot_download

model = snapshot_download("oran9er/STILL-Qwen3.5-9B", revision="81d9373e1dd9c07c537d5fb2436b36a26a2206b4")
Path("STILL-Qwen3.5-9B.location").write_text(model + "\n")
PY
export STILL_ROOT="$PWD/upstream" HF_HUB_OFFLINE=1
export OMP_NUM_THREADS=4 TOKENIZERS_PARALLELISM=false
```

6. Score the development layouts and lock the thresholds.

```sh
python3 prepare.py . "$images/exploratory-inputs.zip" "$images/delivered-rgb.zip"
python3 infer.py . dev
python3 evaluate.py calibrate . "$audit/paper/evidence/exploratory-decisions.csv"
```

7. Score the main layouts and rebuild the tables.

```sh
python3 infer.py . main
python3 evaluate.py evaluate . "$audit/paper/evidence/queries.csv" "$audit/paper/evidence/pairs.csv"
```

The saved projections contain only the predicted box, revisit index and visible fraction.
`sources.json` identifies the Pi3 code and weights for reproducing the projections separately.
