"""Check author scores and the published baseline at the original query and pair level."""
import csv
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

root, evidence = map(Path, sys.argv[1:])

def rows(file):
    with file.open(newline="") as stream:
        return list(csv.DictReader(stream))

def data(name):
    return json.loads((root / name).read_text())

def digest(name):
    return hashlib.sha256((root / name).read_bytes()).hexdigest()

source = {r["id"]: r for r in rows(evidence / "queries.csv")}
table = {r["id"]: r for r in rows(root / "main-decisions.csv")}
thresholds = data("thresholds.json")
settings = data("settings.json")
min_mass = {}
for split in ("dev", "main"):
    aliases = data(f"aliases-{split}.json")
    anchors = data(f"pi3_anchor_cmpe_{split}.json")
    assert set(anchors) == set(aliases.values())
    valid = {k for k, (frame, box, fraction) in anchors.items()
             if frame == 1 and box and box[2] > box[0] and box[3] > box[1] and fraction >= .3}
    scores = {}
    for question, expected in (("scene", set(anchors)), ("place", valid)):
        raw = data(f"probabilities-{split}-{question}.json")
        binding, scores[question] = raw["binding"], raw["rows"]
        assert binding["items_sha256"] == data("preparation.json")[split]["blinded_items_sha256"]
        assert binding["anchor_sha256"] == digest(f"pi3_anchor_cmpe_{split}.json")
        assert binding["code_sha256"] == digest("infer.py")
        assert binding["settings_sha256"] == digest("settings.json")
        assert binding["weights_sha256"] == settings["model_weights_sha256"]
        assert binding["thresholds_sha256"] == (digest("thresholds.json") if split == "main" else None)
        assert binding["words"] == ["same", "changed", "unseen"]
        assert set(scores[question]) == expected and len(expected) == binding["count"]
        min_mass[f"{split}-{question}"] = min(s["answer_token_mass"] for s in scores[question].values())
        assert min_mass[f"{split}-{question}"] >= 1e-9
        for s in scores[question].values():
            assert len(s["p"]) == 3 and min(s["p"]) >= 0 and abs(sum(s["p"]) - 1) < 1e-5
    if split == "dev":
        labels = {r["id"]: r["physical_state"] for r in rows(evidence / "exploratory-decisions.csv")
                  if r["level"] in {"D0","D6"}}
        assert len(labels) == len(aliases) == 800 and set(labels) == set(aliases)
    else:
        assert len(source) == len(table) == len(aliases) == 1280 and set(source) == set(table) == set(aliases)

    dev_counts = Counter()
    actions = {}
    for uid, item in aliases.items():
        place = round(scores["place"][item]["p"][1], 5) if item in valid else None
        scene = round(scores["scene"][item]["p"][1], 5)
        fused = math.sqrt(scene * place) if place is not None else scene
        decisions = {}
        for mode, value in (("place", place), ("fused", fused), ("place_conservative", place)):
            action = "UNKNOWN" if value is None else "REMOVED" if value >= thresholds[mode]["threshold"] else "NO_DELETE"
            decisions["still_" + mode] = action
            if split == "dev":
                dev_counts[mode, labels[uid], action == "REMOVED"] += 1
            else:
                assert table[uid]["still_" + mode] == action
        if split == "main":
            row = source[uid]
            assert table[uid]["truth"] == row["truth"] and table[uid]["engine"] == row["engine"]
            for col, original in (("homography", "homography"), ("dense", "dense"), ("registered_qwen", "registered")):
                decisions[col] = row[original]
                assert decisions[col] == table[uid][col]
            actions[uid] = decisions
    if split == "dev":
        for mode in ("place", "fused", "place_conservative"):
            assert dev_counts[mode, "REMOVED", True] == thresholds[mode]["detected_removals"]
            assert dev_counts[mode, "PRESENT", True] == thresholds[mode]["false_deletions"]
            assert dev_counts[mode, "REMOVED", False] == thresholds[mode]["missed_removals"]

counts = rows(root / "counts.csv")
for reported in counts:
    cohort = [uid for uid,r in source.items()
              if (reported["engine"] == "both" or r["engine"] == reported["engine"])
              and (reported["subset"] == "full" or r["registered_gate"] == "accepted")]
    method = reported["method"]
    removed = sum(source[u]["truth"] == "REMOVED" for u in cohort)
    missed = sum(source[u]["truth"] == "REMOVED" and actions[u][method] != "REMOVED" for u in cohort)
    false = sum(source[u]["truth"] == "PRESENT" and actions[u][method] == "REMOVED" for u in cohort)
    expected = (removed, removed-missed, missed, len(cohort)-removed, false, sum(actions[u][method] == "UNKNOWN" for u in cohort))
    assert expected == tuple(int(reported[k]) for k in ("removed", "detected_removals", "missed_removals", "retained", "false_deletions", "unknown"))

pairs = [r for r in rows(evidence / "pairs.csv") if r["exact"] == "1"]
assert len(pairs) == 88 and {r["engine"] for r in pairs} == {"mujoco"}
for method_record in rows(root / "exact-pairs.csv"):
    method = method_record["method"]
    identical_actions = Counter()
    for r in pairs:
        u,v = r["present_id"], r["removed_id"]
        assert aliases[u] == aliases[v] and actions[u][method] == actions[v][method]
        identical_actions[actions[u][method]] += 1
    assert int(method_record["delete_both"]) == identical_actions["REMOVED"]
    assert int(method_record["unknown_both"]) == identical_actions["UNKNOWN"]

support = Counter()
for uid,r in source.items():
    primary = actions[uid]["still_place"]
    if primary == "UNKNOWN":
        support["no_usable_registration_" + r["truth"].lower()] += 1
    if primary == "REMOVED" and r["truth"] == "PRESENT":
        visible, isolated = int(r["visible_isolated_overlap_pixels"]), int(r["isolated_pixels"])
        assert isolated > 0 and 0 <= visible <= isolated
        band = "hidden" if visible == 0 else "fully_exposed" if visible == isolated else "partial"
        support["primary_false_deletions_" + band] += 1
recount = dict(queries_checked=len(table), aggregate_rows_checked=len(counts), opposite_state_pairs_checked=len(pairs),
               settings_sha256=digest("settings.json"), thresholds_sha256=digest("thresholds.json"),
               development_threshold_counts_match=True, all_main_decisions_match=True,
               all_count_rows_match=True, identical_inputs_have_identical_decisions=True,
               minimum_answer_token_mass=min_mass, primary_diagnostics=dict(support))
(root / "raw-recount.json").write_text(json.dumps(recount, indent=2) + "\n")
print(json.dumps(recount, indent=2))
