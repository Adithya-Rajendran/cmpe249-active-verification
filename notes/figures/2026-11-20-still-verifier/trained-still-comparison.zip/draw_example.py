"""Show the classifier inputs for the exact pair that exceeds the conservative threshold."""
import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image


def draw(root, pairs_csv, output):
    def data(name):
        return json.loads((root / name).read_text())

    aliases = data("aliases-main.json")
    probabilities = data("probabilities-main-place.json")["rows"]
    strict_cut = data("thresholds.json")["place_conservative"]["threshold"]
    with pairs_csv.open(newline="") as stream:
        candidates = []
        for row in csv.DictReader(stream):
            if row["exact"] != "1":
                continue
            uid = aliases[row["present_id"]]
            assert uid == aliases[row["removed_id"]]
            score = probabilities.get(uid)
            if score is not None and round(score["p"][1], 5) >= strict_cut:
                candidates.append((row, uid, score["p"][1]))
    (pair, uid, score), = candidates
    with plt.rc_context({"font.family": "DejaVu Sans", "text.color": "#1e252b"}):
        fig, axes = plt.subplots(1, 2, figsize=(6.5, 2.7))
        fig.subplots_adjust(left=.025, right=.975, top=.84, bottom=.22, wspace=.07)
        for ax, suffix, title in zip(axes, ("object", "place"), ("Earlier target", "Revisit in both physical states")):
            with Image.open(root / f"{uid}-{suffix}.jpg") as im:
                ax.imshow(im, interpolation="nearest")
            ax.set_anchor("N")
            ax.set_axis_off()
            ax.set_title(title, fontsize=11, pad=7)
        fig.text(.5, .09, f"MuJoCo tabletop {pair['arrangement']}  ·  {pair['level']} / {pair['stop']}"
                 f"  ·  STILL change score {score:.5f}", ha="center", fontsize=9)
        fig.savefig(output, dpi=180, facecolor="white")
        plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("pairs_csv", type=Path)
    parser.add_argument("output_png", type=Path)
    args = parser.parse_args()
    draw(args.directory, args.pairs_csv, args.output_png)
