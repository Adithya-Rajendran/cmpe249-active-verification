"""Lock operating points on exploratory layouts, then join blinded scores to physical states."""
import argparse
import csv
import hashlib
import json
import math
import random
from collections import defaultdict
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_read(path):
    return json.loads(path.read_text())


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        output = csv.DictWriter(stream, fieldnames=list(rows[0]))
        output.writeheader()
        output.writerows(rows)


def scores(root, split):
    aliases = json_read(root / f"aliases-{split}.json")
    unique_ids = set(aliases.values())
    views = {}
    for mode in ("place", "scene"):
        raw = json_read(root / f"probabilities-{split}-{mode}.json")
        b = raw["binding"]
        if (b["mode"], b["split"], b["settings_sha256"]) != (mode, split, digest(root / "settings.json")):
            raise ValueError("Incorrect probability-file binding")
        if split == "main" and b["thresholds_sha256"] != digest(root / "thresholds.json"):
            raise ValueError("Main scoring used a different threshold lock")
        if len(raw["rows"]) != b["count"] or not set(raw["rows"]) <= unique_ids:
            raise ValueError("Missing or extraneous model outputs")
        views[mode] = {uid: round(row["p"][1], 5) for uid, row in raw["rows"].items()}
    if set(views["scene"]) != unique_ids:
        raise ValueError("Missing whole-image output")
    result = {}
    for uid, rep in aliases.items():
        scene = views["scene"][rep]
        place = views["place"].get(rep)
        fused = math.sqrt(scene * place) if place is not None else scene
        result[uid] = dict(canonical_id=rep, scene=scene, place=place, fused=fused)
    return result


def operating_points(results, truth, mode):
    positives = sum(truth.values())
    thresholds = {r[mode] for r in results.values()} - {None}
    thresholds.add(math.nextafter(1.0, math.inf))
    points = []
    for cut in thresholds:
        deleted = [uid for uid, r in results.items() if r[mode] is not None and r[mode] >= cut]
        hits = sum(truth[uid] for uid in deleted)
        false = len(deleted) - hits
        f1 = Fraction(2 * hits, positives + len(deleted))
        points.append((f1, -false, cut, hits))
    regular = max(points)
    conservative = max((p for p in points if p[1] == 0), key=lambda p: (p[3], p[2]))

    def record(point):
        f1, neg_false, cut, hits = point
        return dict(threshold=cut, f1=float(f1), detected_removals=hits, missed_removals=positives-hits,
                    false_deletions=-neg_false, actually_removed=positives, actually_retained=len(truth)-positives)
    return record(regular), record(conservative)


def calibrate(root, dev_csv):
    rows = [r for r in read_csv(dev_csv) if r["level"] in ("D0", "D6")]
    measured = scores(root, "dev")
    truth = {r["id"]: r["physical_state"] == "REMOVED" for r in rows}
    layouts = {r["base_id"] for r in rows}
    if len(truth) != 800 or sum(truth.values()) != 400 or len(layouts) != 10 or set(truth) != set(measured):
        raise ValueError("Unexpected calibration cohort")
    place, conservative = operating_points(measured, truth, "place")
    fused, _ = operating_points(measured, truth, "fused")
    lock = dict(settings_sha256=digest(root / "settings.json"), calibration_csv_sha256=digest(dev_csv),
                development_layouts=sorted(layouts), calibration_inputs=800,
                place=place, fused=fused, place_conservative=conservative,
                place_available=sum(r["place"] is not None for r in measured.values()),
                probability_files={mode: digest(root / f"probabilities-dev-{mode}.json")
                                   for mode in ("place", "scene")})
    path = root / "thresholds.json"
    if path.exists():
        prior = json_read(path)
        if {k: prior[k] for k in lock} != lock:
            raise ValueError("Existing numeric lock differs from development-only recount")
        return
    lock["locked_utc"] = datetime.now(timezone.utc).isoformat()
    with path.open("x") as stream:
        stream.write(json.dumps(lock, indent=2) + "\n")
    print(json.dumps(lock, indent=2))


METHODS = ("homography", "dense", "registered_qwen", "still_place", "still_fused", "still_place_conservative")


def tabulate(rows, subset, engine):
    result = []
    for method in METHODS:
        removed = [r for r in rows if r["truth"] == "REMOVED"]
        retained = [r for r in rows if r["truth"] == "PRESENT"]
        hits = sum(r[method] == "REMOVED" for r in removed)
        false = sum(r[method] == "REMOVED" for r in retained)
        result.append(dict(subset=subset, engine=engine, method=method, removed=len(removed),
                           detected_removals=hits, missed_removals=len(removed) - hits,
                           retained=len(retained), false_deletions=false,
                           unknown=sum(r[method] == "UNKNOWN" for r in rows)))
    return result


def paired_intervals(rows):
    """Descriptive intervals conditional on the locked threshold; resample whole shared layouts."""
    strata = defaultdict(set)
    for row in rows:
        strata[row["environment"]].add(row["arrangement"])
    rng = random.Random(20261120)
    draws = [[] for _ in range(10_000)]
    for sample in draws:
        for environment in sorted(strata):
            layouts = sorted(strata[environment])
            sample.extend(rng.choices(layouts, k=len(layouts)))

    output = []
    for engine in ("both", "isaac", "mujoco"):
        cohort = [r for r in rows if engine == "both" or r["engine"] == engine]
        for base in ("dense", "registered_qwen"):
            for truth, metric in (("REMOVED", "missed_removals"), ("PRESENT", "false_deletions")):
                by_layout = defaultdict(int)
                sizes = defaultdict(int)
                for r in cohort:
                    if r["truth"] == truth:
                        # A delete is an error on PRESENT; withholding is an error on REMOVED.
                        diff = int(r["still_place"] == "REMOVED") - int(r[base] == "REMOVED")
                        by_layout[r["arrangement"]] += -diff if truth == "REMOVED" else diff
                        sizes[r["arrangement"]] += 1
                if len(set(sizes.values())) != 1 or len(sizes) != 16:
                    raise ValueError("Bootstrap requires the balanced main panel")
                denominator = sum(sizes.values())
                dist = sorted(100 * sum(by_layout[k] for k in draw) / denominator for draw in draws)
                def percentile(q):
                    rank = (len(dist) - 1) * q
                    lo = math.floor(rank)
                    return dist[lo] + (rank - lo) * (dist[math.ceil(rank)] - dist[lo])
                output.append(dict(engine=engine, baseline=base, metric=metric,
                                   difference_pp=100*sum(by_layout.values())/denominator,
                                   lower95_pp=percentile(.025), upper95_pp=percentile(.975)))
    return output


def evaluate(root, main_csv, pairs_csv):
    records = read_csv(main_csv)
    pairs = read_csv(pairs_csv)
    measured = scores(root, "main")
    cut = json_read(root / "thresholds.json")
    if len(records) != 1280 or set(r["id"] for r in records) != set(measured):
        raise ValueError("Unexpected main cohort")
    layouts = {r["arrangement"] for r in records}
    if len(layouts) != 16 or layouts & set(cut["development_layouts"]):
        raise ValueError("Layout count or split mismatch")
    joined = {}
    for r in records:
        uid = r["id"]
        score = measured[uid]
        row = {k: r[k] for k in ("id", "engine", "environment", "arrangement", "level", "stop", "state", "truth")}
        row.update(score)
        row.update(homography=r["homography"], dense=r["dense"], registered_qwen=r["registered"],
                   original_gate_passed=r["registered_gate"] == "accepted")
        for m in ("place", "fused", "place_conservative"):
            value = score["place" if m == "place_conservative" else m]
            row["still_" + m] = ("UNKNOWN" if value is None else
                                 "REMOVED" if value >= cut[m]["threshold"] else "NO_DELETE")
        joined[uid] = row
    all_rows = list(joined.values())
    write_csv(root / "main-decisions.csv", all_rows)
    admitted = [r for r in all_rows if r["original_gate_passed"]]
    if len(admitted) != 834:
        raise ValueError("Unexpected original registration subset")
    counts = []
    for subset, selected in (("full", all_rows), ("old_registration_pass", admitted)):
        for engine in ("both", "isaac", "mujoco"):
            rows = selected if engine == "both" else [r for r in selected if r["engine"] == engine]
            counts.extend(tabulate(rows, subset, engine))
    write_csv(root / "counts.csv", counts)
    exact = [p for p in pairs if p["exact"] == "1"]
    if len(exact) != 88 or {p["engine"] for p in exact} != {"mujoco"}:
        raise ValueError("Unexpected pixel-identical pairs")
    exact_counts = []
    for method in METHODS:
        kept = [joined[p["present_id"]][method] for p in exact]
        gone = [joined[p["removed_id"]][method] for p in exact]
        if kept != gone:
            raise ValueError("Identical inputs produced unequal actions")
        exact_counts.append(dict(method=method, exact_pairs=len(exact),
                                 delete_both=kept.count("REMOVED"), unknown_both=kept.count("UNKNOWN"),
                                 other_non_delete_both=len(kept)-kept.count("REMOVED")-kept.count("UNKNOWN")))
    write_csv(root / "exact-pairs.csv", exact_counts)
    write_csv(root / "paired-differences.csv", paired_intervals(all_rows))
    print(json.dumps([r for r in counts if r["subset"] == "full" and r["engine"] == "both"], indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    dev = sub.add_parser("calibrate")
    dev.add_argument("directory", type=Path)
    dev.add_argument("development_csv", type=Path)
    main = sub.add_parser("evaluate")
    main.add_argument("directory", type=Path)
    main.add_argument("queries_csv", type=Path)
    main.add_argument("pairs_csv", type=Path)
    args = parser.parse_args()
    if args.command == "calibrate":
        calibrate(args.directory, args.development_csv)
    else:
        evaluate(args.directory, args.queries_csv, args.pairs_csv)
