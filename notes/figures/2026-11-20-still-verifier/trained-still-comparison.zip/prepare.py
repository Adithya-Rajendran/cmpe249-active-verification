"""Bind content-addressed release RGBs and reference boxes to the authors' two-frame prompt."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

from restore_inputs import restore


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def prepare(root, split, archive, checksum, selected, question):
    if digest(archive) != checksum:
        raise ValueError(f"Archive checksum mismatch for {split}")
    packet = root / "packets" / split
    if not packet.exists():
        restore(archive, packet)
    cases = json.loads((packet / "cases.json").read_text())
    representatives, aliases, rows = {}, {}, []
    for case in sorted(cases, key=lambda r: r["id"]):
        uid = case["id"]
        if selected is not None and uid not in selected:
            continue
        box = [round(v * 1000 / dim) for v, dim in zip(case["box_xyxy"], (1200, 675, 1200, 675))]
        if not (0 <= box[0] < box[2] <= 1000 and 0 <= box[1] < box[3] <= 1000):
            raise ValueError("Invalid reference box")
        key = case["reference_sha256"], case["query_sha256"], tuple(box)
        representative = representatives.setdefault(key, uid)
        aliases[uid] = representative
        if representative != uid:
            continue
        paths = [packet / case[role] for role in ("reference", "query")]
        if any(digest(p) != h for p, h in zip(paths, key[:2])):
            raise ValueError(f"Restored RGB digest mismatch for {uid}")
        rows.append(dict(id=uid, item=uid, task="bin3", n1=1, n2=1, images=list(map(str, paths)),
                         query={"video": 1, "frame": 1, "bbox_2d": box, "score": 1.0},
                         q=question.format(v=1, w=2, f=1, b=box)))
    if len(aliases) != (800 if split == "dev" else 1280):
        raise ValueError(f"Invalid number of cases for {split}")
    out = root / "upstream" / "data" / "p2" / f"items_cmpe_{split}.jsonl"
    out.write_text("".join(json.dumps(r) + "\n" for r in rows))
    (root / f"aliases-{split}.json").write_text(json.dumps(aliases, sort_keys=True) + "\n")
    return set(representatives), {"cases": len(aliases), "distinct_inputs": len(rows),
                                  "packet_manifest_sha256": digest(packet / "cases.json"),
                                  "blinded_items_sha256": digest(out)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    ap.add_argument("dev_archive", type=Path)
    ap.add_argument("main_archive", type=Path)
    args = ap.parse_args()
    stage = args.root.resolve()
    sys.path.insert(0, str(stage / "upstream/scripts"))
    from build_verify import Q
    settings = json.loads((stage / "settings.json").read_text())
    ids = set((stage / "dev-ids.txt").read_text().splitlines())
    dev, dev_receipt = prepare(stage, "dev", args.dev_archive, settings["exploratory_archive_sha256"], ids, Q)
    main, main_receipt = prepare(stage, "main", args.main_archive, settings["main_archive_sha256"], None, Q)
    if dev & main:
        raise ValueError("Calibration and evaluation input sets overlap")
    receipt = {"dev": dev_receipt, "main": main_receipt, "overlapping_complete_inputs": 0}
    (stage / "preparation.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(receipt, flush=True)
